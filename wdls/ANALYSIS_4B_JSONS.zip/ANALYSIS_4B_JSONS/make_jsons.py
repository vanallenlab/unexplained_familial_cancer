import json
import os

pgs_ids = [
    "PGS004688",
    "PGS004241",
    "PGS000782",
    "PGS004687",
    "PGS000784",
    "PGS003389",
    "PGS000785",
    "PGS003386",
    "PGS004243",
    "PGS004689",
    "PGS000786",
    "PGS003381",
    "PGS004244",
    "PGS000787",
    "PGS004690",
    "PGS004245",
    "PGS000788",
    "PGS000789",
    # Handle the comma-separated group by splitting into individual IDs
    *"PGS003391,PGS003392,PGS003393".split(","),
    "PGS004246",
    "PGS004691",
    "PGS000790",
    "PGS003382",
    "PGS004247",
    "PGS000791",
    "PGS004248",
    "PGS000793",
    "PGS003385",
    "PGS004249",
    "PGS004692",
    "PGS000794",
    "PGS004250",
    "PGS004693",
    "PGS000795",
    "PGS003383",
    "PGS004251",
    "PGS004694"
]

# Output directory (optional)
out_dir = "pgs_jsons"
os.makedirs(out_dir, exist_ok=True)

for pgs_id in pgs_ids:
    data = {
        "ANALYSIS_4B_PRS.PGS_ID": pgs_id,
        "ANALYSIS_4B_PRS.raw_prs_basename": f"{pgs_id}.raw.pgs"
    }
    out_file = os.path.join(out_dir, f"{pgs_id}.json")
    with open(out_file, "w") as f:
        json.dump(data, f, indent=2)

print(f"Wrote {len(pgs_ids)} JSON files into '{out_dir}/'")

